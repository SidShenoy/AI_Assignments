package core;

public class Properties
{
	public static String VERSION = "0.0.4 ALPHA";
}